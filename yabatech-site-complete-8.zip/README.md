# YABATECH CGPA Calculator

A free website for YABATECH students: GPA/CGPA calculator, target planner, department plan, department directory, GPA statistics page and exam venue lookup.

Built with plain HTML, CSS and JavaScript (no build step).

## Files
- `index.html` - page structure
- `style.css` - design
- `script.js` - all the logic (calculators, login, search). Paste your Firebase config near the bottom to switch on cloud accounts and the live visitor counter.
- `departments.js` - departments and their locations
- `exams.js` - exam venues (edit before exams, then set `EXAM_SAMPLE` to `false`)
- `IMG-20261009-WA0049.jpg` - YABATECH logo
- `school-*.jpg` - school photos

## Run locally
Open `index.html` in a browser.

## Deploy with GitHub Pages
Repository Settings > Pages > Deploy from a branch > `main` / `(root)` > Save.
